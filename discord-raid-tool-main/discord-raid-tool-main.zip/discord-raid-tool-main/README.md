# Discord Raid Multi-Tool

Welcome to Bloody V2, a powerful tool designed to efficiently raid Discord servers. With this tool, you have a lot of options that make you able to customize exactly how you want to raid the server.

![cmd_3hrCdyMXYM](https://github.com/Venaste/discord-raid-tool/assets/165221254/bc233e11-12ba-472c-af23-496559c52f7c)

## Showcases

Soon!

## Features

- **Joiner**
- **Leaver**
- **Checker**
- **Spammer**
- **Inviter**
- **Typing**
- **Mass DM**
- **Reaction Bomber**
- **Emoji Reactor**
- **Thread Flooder**
- **VoiceChat Joiner**
- **Soundboard Spammer**
- **Token Formatter**
- **BIO Changer**
- **Name Changer**
- **Nick Changer**
- **RestoreCorder**
- **SelfScraper**
- **Boost Server**
- **DM Spammer**
- **Call Spammer**
- **Button Clicker**
- **Friend Spam**
- **Accept Rules**
- **Guild Check**
- **Token Captcher**
- **Ticket Spam**
- **And more!**
  

## Installation

To get started with the Bloody V2 Raider, follow these steps:

0. <a href="https://www.python.org/downloads/" style="color: blue;">Install Python</a>

1. Save the repository as a zip file on your PC.

2. Extract the ZIP file.

3. Open Install.bat to install the Python requirements. When its done:

4. Run the tool by opening start.bat or typing `python main.py` into cmd in the correct path.

5. Enjoy!

### Make sure to but tokens in tokens.txt etc.

## Disclaimer

I do not encourage nuking discord servers. This is just a showcase of a coding project. I take no responsibility for harm caused by this software.
